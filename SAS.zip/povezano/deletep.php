<?php
session_start();
$b=$_SESSION['id'];
$id=$_POST['idd'];
   
   include "connection.php";

   $sql = "delete from post where id='$id'";
   $result = $konekcija->query($sql);
   header('location:mojiPostovi.php');