$(window).load(function(){
    $( "#change_background" ).on( "click", function() {
        $("body").first().css("background-color","darkgrey");
         $("body").first().css("color","white");
    });
});