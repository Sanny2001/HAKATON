function validation()
{ 
      var letters = /^[A-Za-z]+$/;
      var ime = document.getElementById("ime");
      var prezime = document.getElementById("prezime");
      var password1 = document.getElementById("password1").value;
      var password2 = document.getElementById("password2").value;
      var datum = document.getElementById("datum");
      var email = document.getElementById("email").value;
      var tel = document.getElementById("tel");
      var drzava = document.getElementById("drzava").value;

      if(ime.value == "" || prezime.value == "" || password1 == "" || password2 == "" || datum.value == "" || email == "" || tel.value == ""){
            alert("Morate popuniti sva polja!");
            return false;
      }

      if(ime.value.match(letters))
      {
            //alert('Your name have accepted : you can try another');
      }
      else
      {
            alert('Ime mora sadrzati samo slova!');
            return false;
      }

      if(prezime.value.match(letters))
      {
            //alert('Your name have accepted : you can try another');
      }
      else
      {
            alert('Prezime mora sadrzati samo slova!');
            return false;
      }

      if(password1 == password2){
      }
      else{
            alert("Lozinke se ne poklapaju!");
            return false;
      }


      var re = /^\d{1,2}\/\d{1,2}\/\d{4}$/;

      if(datum.value != '' && !datum.value.match(re)) 
      {
            alert("Ne valja: " + form.startdate.value);
            datum.focus();
            return false;
      }


      var numbers = /^[0-9]+$/;
      if(tel.value.match(numbers))
      {
      }
      else
      {
      alert('Broj telefona je invalidan');
      document.tel.focus();
      return false;
      }

      if(drzava == "Opcije"){
            alert("Morate izabrati drzavu!");
            return false;
      }


      alert("brao");
      return true;
}