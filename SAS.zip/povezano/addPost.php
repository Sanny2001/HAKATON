<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>


  <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">

<style>
/* Add padding to containers */
body{
  background-color: #745a5296;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: white;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #f4623a;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #745a5296;
  text-align: center;
}
</style>
</head>
<body class="page-top">
   <?php  if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
     include('includes/navuser.php');

 }
    else
      include('includes/nav.php');
?>

  <!-- Masthead -->
<!--border-style: solid; border-color: gray; border-width: 1px-->
  <div class="container" style="width: 60%; background-color: white; padding: 2% 3% 2% 3%; height: 800px;">
   <form method="POST" action="addpostb.php">
	<div style="margin-top: 15%">
      <div class="col-form-label col-3"><p style="font-style: italic;"><b>Naslov</b></p></div>
      <div class="col-9"><input type="text" name="title" class="form-control" placeholder="Naslov"></div>
    </div>
    <div>
      <div class="col-form-label col-3"><p style="font-style: italic;"><b>Mesto</b></p></div>
      <div class="col-9"><input type="text" name="location" class="form-control" placeholder="Mesto"></div>
    </div>
    <div >
      <div class="col-form-label col-3"><p style="font-style: italic;"><b>Datum i vreme</b></p></div>
      <div class="col-9"><input type="datetime-local" name="time"></div>
    </div>
    <div>
      <div class="col-form-label col"><p style="font-style: italic;"><b>Unesite opis Vaseg dogadjaja</b></p></div>
    </div>
    <div >
      <div class="col-12"><textarea rows="5" cols="" style="width: 100%" name="descr" placeholder="Opis"></textarea></div>
    </div>
    <div >
      <input type="hidden" name="a" value="<?php $id=$_SESSION['id']; echo "$id" ?>" />
      <div class="col-2"><button class="btn btn-primary" style="width: 100%;margin-bottom:2%">Submit</button></div>
      <div class="col-2"><button class="btn btn-primary" style="width: 100%">Edit</button></div>
    </div>
	</form>
  </div>


<section class="page-section bg-dark text-white" id="contact">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">Kontakt</h2>
          <hr class="divider my-4">
          <p class="text-muted mb-5">Pozovite nas ili nas kontaktirajte putem e-mail</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <i class="fas fa-phone fa-3x mb-3 text-muted"></i>
          <div>+1 (202) 555-0149</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <a class="d-block" href="mailto:contact@yourwebsite.com">nas@emajl.com</a>
        </div>
      </div>
    </div>
  </section>
    <?php 
  include ('includes/footer.php');
  ?>
    <script type="text/javascript" src="js/bgcc.js"></script>
  </body>
</html>
