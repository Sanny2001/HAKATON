<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">

  <title>Culture</title>

  <!-- Font Awesome Icons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

<!-- Latest compiled JavaScript -->  <script type='text/javascript'
  src='http://code.jquery.com/jquery-1.11.0.js'></script>
  <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">
</head>


<body id="page-top">

  <!-- Navigation -->
  <!-- Navigation -->

 <?php  if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
     include('includes/navuser.php');

 }
    else
      include('includes/nav.php');
?>  
  <header class="masthead">
    <div class="container h-100">
      <div class="row h-100 align-items-center justify-content-center text-center">
        <div class="col-lg-10 align-self-end">
          <h1 class="text-uppercase text-white font-weight-bold">Dobrodošli na kulturnu stranicu SAS</h1>
          <hr class="divider my-4">
        </div>
        <div class="col-lg-8 align-self-baseline">
          <p class="text-white-75 font-weight-light mb-5">Omugućujemo velik broj kulturnih manifestacija u najrazličitijim vidovima. Mi smo ovde da vam nijedan od tih događaja ne promakne!</p>
          <a class="btn btn-primary btn-xl js-scroll-trigger" href="SviPostovi.php">Saznajte više</a>
        </div>
      </div>
    </div>
  </header>

  <!-- About Section -->
  <section class="page-section bg-dark" id="about">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-3 offset-1 text-center">
          <img src="logoveci.png" style="max-width: 100%; max-height: 100%;">
        </div>
        <div class="col-lg-6 offset-2 text-center">
          <h2 class="text-white mt-0">SAS organizacija</h2>
          <hr class="divider light my-4">
          <p class="text-white-50 mb-4">SAS je kreiran sa ciljem da svim ljubiteljima kulture (i onima koji će to tek postati) omogući detaljan pregled budućih kulturnih događaja u Novom Sadu. Pronaći ćete tačnu satnicu, lokaciju i kratak opis događaja koji je najavljen u narednom periodu</p>
          <a class="btn btn-light btn-xl js-scroll-trigger" href="#services">Detaljnije</a>
        </div>
      </div>
    </div>
  </section>


<section class="page-section bg-primary" id="about">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2 class="text-white mt-0">Održava se događaj u tvom gradu?</h2>
          <hr class="divider light my-4">
          <p class="text-white-50 mb-4">Start Bootstrap has everything you need to get your new website up and running in no time! Choose one of our open source, free to download, and easy to use themes! No strings attached!</p>
          <a class="btn btn-light btn-xl js-scroll-trigger" href="login.php">Detaljnije</a>
        </div>
        <div class="col-3 offset-1 text-center">
          <img src="img/megafon.png" style="max-width: 100%; max-height: 100%;">
        </div>
      </div>
    </div>
  </section>


  <section class="page-section bg-dark" id="about">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-6 text-center">
          <img src="img/friends.png" style="max-width: 100%; max-height: 100%;">
        </div>
        <div class="col-lg-6 text-center">
          <h2 class="text-white mt-0">Zanima te šta se dešava u tvom gradu?</h2>
          <hr class="divider light my-4">
          <p class="text-white-50 mb-4">Ako znate za neki događaj ili ste u ulozi organizatora, a mi ga još uvek nismo objavili, jednostavno popunite kratku formu i vaš događaj biće na našoj listi.</p>
          <a class="btn btn-light btn-xl js-scroll-trigger" href="login.php">Detaljnije</a>
        </div>
      </div>
    </div>
  </section>


  <section class="page-section bg-primary" id="about">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6 text-center">
          <h2 class="text-white mt-0">Stupite u kontakt sa organizatorima</h2>
          <hr class="divider light my-4">
          <p class="text-white-50 mb-4">Osim toga, registrovani posetioci sajta biće u prilici da razmene utiske, očekivanja i mišljenja jedni sa drugima, ili da se prosto virtuelno druže, četujući u delu namenjenom za to.</p>
          <a class="btn btn-light btn-xl js-scroll-trigger" href="login.php">Detaljnije</a>
        </div>
        <div class="col-3 offset-1 text-center">
          <img src="img/addfriend.png" style="max-width: 100%; max-height: 100%;">
        </div>
      </div>
    </div>
  </section>

  <!-- Services Section -->
  <section class="page-section" id="services">
    <div class="container">
      <h2 class="text-center mt-0">Citati o kulturi</h2>
      <hr class="divider my-4">
      <div class="row">
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-gem text-primary mb-4">
            <p class="text-muted mb-0">Književna kultura to je čitanje.</p></i>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-laptop-code text-primary mb-4">
            <p class="text-muted mb-0">Pojam kulture nekako izmiče našem intelektu i javlja nam se u svoj svojoj neodređenosti i zbog toga ga je teško opisati i tumačiti.</p></i>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-globe text-primary mb-4">
            <p class="text-muted mb-0">Arheolozi tragaju za ostacima ranijih kultura, kao da ostaci današnje kulture nisu dovoljni.</p></i>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 text-center">
          <div class="mt-5">
            <i class="fas fa-4x fa-heart text-primary mb-4">
            <p class="text-muted mb-0">Ko je uljudan preko mene postaje dosadan.</p></i>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Portfolio Section -->


  <!-- Contact Section -->
  <section class="page-section bg-dark text-white" id="contact">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">Kontakt</h2>
          <hr class="divider my-4">
          <p class="text-muted mb-5">Pozovite nas ili nas kontaktirajte putem e-mail</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <i class="fas fa-phone fa-3x mb-3 text-muted"></i>
          <div>+1 (202) 555-0149</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <a class="d-block" href="mailto:contact@yourwebsite.com">sas@smart.edu.rs</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
<?php 
  include ('includes/footer.php');
  ?>

  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bgcc.js"></script>
  
  
</body>

</html>
