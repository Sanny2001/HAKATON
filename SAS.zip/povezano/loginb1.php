<?php
   include("connection.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($konekcija,$_POST['email']);
      $mypassword = mysqli_real_escape_string($konekcija,$_POST['pass']); 
      
      $sql = "SELECT id,email FROM user WHERE email = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($konekcija,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['id'];
      $active1 = $row['email'];

      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         $_SESSION['id'] = $active;
         $_SESSION['email'] = $active1;

         foreach ($_SESSION as $key=>$val)
    echo $key." ".$val."<br/>";
   
    header ('location:index.php');
      }else {
         $error = "Your Login Name or Password is invalid";
         echo "a";
      }
   }
?>
