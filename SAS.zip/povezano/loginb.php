<?php
$email=$_POST['email'];
$f_name=$_POST['f_name'];
$phone=$_POST['tel'];

$l_name=$_POST['l_name'];
$password=$_POST['password'];
    require "connection.php";

    $sql = "insert into user(email,f_name,l_name,password,phone) values('$email','$f_name','$l_name','$password','$phone');";
$result = $konekcija->query($sql);

include("connection.php");
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST") {
   // username and password sent from form 
   
   $myusername = mysqli_real_escape_string($konekcija,$_POST['email']);
   $mypassword = mysqli_real_escape_string($konekcija,$_POST['password']); 
   
   $sql = "SELECT id FROM user WHERE email = '$myusername' and password = '$mypassword'";
   $result = mysqli_query($konekcija,$sql);
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   $active = $row['id'];
   
   $count = mysqli_num_rows($result);
   
   // If result matched $myusername and $mypassword, table row must be 1 row
     
   if($count == 1) {
       
      $_SESSION['id'] = $active;
      $_SESSION['email'] = $email;

     header("location: login.php");
   }else {
      $error = "Your Login Name or Password is invalid";
      echo "a";
   }
}

$konekcija->close();