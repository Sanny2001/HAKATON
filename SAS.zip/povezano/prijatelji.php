
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Culture</title>

  <!-- Font Awesome Icons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>


  <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">
  <link href="css/search.css" rel="stylesheet">

<style type="text/css">
  
  .people-nearby .google-maps{
  background: #f8f8f8;
  border-radius: 4px;
  border: 1px solid #f1f2f2;
  padding: 20px;
  margin: 20px 20px 20px 20px;
}

.people-nearby .google-maps .map{
  height: 300px;
  width: 100%;
  border: none;
}

.people-nearby .nearby-user{
  padding: 20px 0;
  border-top: 1px solid #f1f2f2;
  border-bottom: 1px solid #f1f2f2;
  margin-bottom: 20px;
  margin: 20px 20px 20px 20px;
}

img.profile-photo-lg{
  height: 80px;
  width: 80px;
  border-radius: 50%;
}


</style>

</head>

<body id="page-top">

<?php

    require "prijateljib.php";
    // učitavanje fajla
    $jsonFajl = file_get_contents("jsonIzBaze2.json");
    // pretvaranje učitanog sadržaja u niz u PHP-u
    $jsonObjekat = json_decode($jsonFajl);
   
    ?>
    <?php

require "zahtevip.php";
// učitavanje fajla
$jsonFajl2 = file_get_contents("prijatelji.json");
// pretvaranje učitanog sadržaja u niz u PHP-u
$jsonObjekat2 = json_decode($jsonFajl2);

?>
  <!-- Navigation -->
 <?php  if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
     include('includes/navuser.php');

 }
    else
      include('includes/nav.php');
?>
<div class="container" style="">
  <div class="row" style="margin-top: 13%; margin-bottom: 7%">
  <div class="col-lg-6" style="">
    <form class="form-inline md-form form-sm active-cyan active-cyan-2 mt-2" style="width:100%">
  <i class="fas fa-search" aria-hidden="true"></i>
  <input class="form-control form-control-sm ml-3 w-75" style="width: 100%; margin-right:16px" type="text" placeholder="Search"
    aria-label="Search">
</form>

    <div class="container" style="margin-top: 20px">
    <div class="row">
        <div class="col-md-12">
            <div class="people-nearby">
            <?php 
                                                          $a=$_SESSION['id'];       
echo "$a";
                            // otkomentarisati sledeći red
                            // alijas elementNiza za elemente niza predmeti
                            
                            foreach ($jsonObjekat->user as $elementNiza) {
                              include "connection.php";
                              $sql = "SELECT * FROM user where id not in (select id_2 from temp where id_1='$a' and status=False) and id<>'$a' ";
                              $result = mysqli_query($konekcija,$sql);
                              $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
                              $s=$elementNiza->id;
                              echo "$s";
                        
                            ?>
                            <form  method="POST" action="addfriend.php">
              <div class="nearby-user" >
                <div class="row">
                  <div class="col-md-2 col-sm-2">
                        <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="user" class="profile-photo-lg">
                  </div>
                  <div class="col-md-7 col-sm-7">
                    <h5><a href="#" class="profile-link"><?php echo "$elementNiza->email"?></a></h5>
                    <p>Software Engineer</p>
                    <p class="text-muted">500m away</p>
                  </div>
                  <div class="col-md-3 col-sm-3">
                    <input type="hidden" id="custId" name="p" <?php echo "name='$s'"; ?>>
                    <button class="btn btn-primary pull-right" name="p" <?php echo "value='$s'" ?> type="sumbit" ></button>

                    <!-- hiden variabla p u formi umesto %s -->
                  </div>
                </div>
              </div>
                            </form>
              <?php
                // otkomentarisati sledeći red
                }
                ?>


            </div>
   </div>
</div>

    </div>
</form>

  </div>
  <div class="col-lg-6" style="">
    <div class="container">
    <h3 style="margin-top: 5px; text-align: center;">Novi zahtevi</h3>
  </div>
                <!-- Proveriti da li vec postoji taj zahtev pre inserta -->
    <div class="container" style="margin-top: 20px">
    <div class="row">
        <div class="col-md-12">
            <div class="people-nearby">
            <?php 
                                                          $a=$_SESSION['id'];       
echo "$a";
                            // otkomentarisati sledeći red
                            // alijas elementNiza za elemente niza predmeti
                        
                            foreach ($jsonObjekat2->temp as $elementNiza) {
                              $sql2 = "select * from temp inner join user on id_2=id where id_1='$a' and status=false";
                              $result2 = mysqli_query($konekcija,$sql2);
                              include "connection.php";
                              $row2 = mysqli_fetch_object($result2);

                              $s2=$elementNiza->id_1;
                              echo "$s2";
                        
                            ?>
              <div class="nearby-user">
                <div class="row">
                  <div class="col-md-2 col-sm-2">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="user" class="profile-photo-lg">
                  </div>
                  <div class="col-md-6 col-sm-6">
                    <h5><a href="#" class="profile-link"><?php echo"$row2->email"?></a></h5>
                    <p>Software Engineer</p>
                    <p class="text-muted">500m away</p>
                  </div>
                  <div class="col-md-2 col-sm-2">
                    
                   <form method="POST" action="accept.php"> <button class="btn btn-primary pull-right" type="sumbit"  ><input type="hidden" id="custId" name="a" <?php echo "value='$row2->id_2'"; ?>> Prihvti</button></form>
                  </div>
                  <div class="col-md-2 col-sm-2">
                  <form method="POST" action="decline.php"> <button class="btn btn-primary pull-right" type="sumbit"  ><input type="hidden" id="custId" name="a" <?php echo "value='$row2->id_1'"; ?>> Odbi</button></form>
                  </div>
                </div>
              </div>
              <?php
                // otkomentarisati sledeći red
                }
                ?>

              </div>

            </div>
   </div>
</div>

    </div>
</form>

  </div>
</div>
</div>







  <!-- Contact Section -->
  <section class="page-section bg-dark text-white" id="contact">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">Kontakt</h2>
          <hr class="divider my-4">
          <p class="text-muted mb-5">Pozovite nas ili nas kontaktirajte putem e-mail</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <i class="fas fa-phone fa-3x mb-3 text-muted"></i>
          <div>+1 (202) 555-0149</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <a class="d-block" href="mailto:contact@yourwebsite.com">nas@emajl.com</a>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Copyright &copy; All rights reserved by us</div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  
  
  
  <!-- Custom scripts for this template -->
  <script src="js/creative.min.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
<script type="text/javascript">
</body>

</html>
