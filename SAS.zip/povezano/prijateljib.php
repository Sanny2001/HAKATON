<?php
session_start();
// učitavanje skripte sa podacima o konekciji
// komande include ili require
require "connection.php";
$a=$_SESSION['id'];
// promenljiva u kojoj čuvamo SQL upit za bazu 
$upit = "SELECT * FROM user where id not in (select id_2 from temp where id_1='$a') and id<>'$a';";


// da li je upit uspešno izvršen
if ( !$rezultat = $konekcija->query($upit) ) {
    // ako dođe do greške
    // pravimo promenljivu (tipa string) koja čuva json podatke o grešci
    $jsonString = '{ "greska": "Neuspesno izvrsavanje." }';
} else {
    //ako je izvršen upit
    // da li rezultat koji je vraćen iz baze ima više od 0 redova
    if ( $rezultat->num_rows > 0 ) {
        // pravimo promenljivu (tipa string) koja čuva json podatke iz baze
        $jsonString = '{ "user": ';
        // inicijalizujemo prazan niz u kom ćemo čuvati predmete
        $niz = array();

        while ( $red = $rezultat->fetch_object() ) {
            // dodajemo sledeći element u niz
            $niz[] = $red;
        }

        // dodajemo postojećoj promenljivoj $jsonString niz koji smo napravili u prethodnoj petlji

        $jsonString .= json_encode($niz);
        // dodajemo promenljivoj zatvorenu vitićastu zagradu
        $jsonString .= '}';
    } else {
        //ako nema rezultata u bazi
        $jsonString = '{"greska":"Nema rezultata."}';
    }
}
// otvaranje novog fajla
// da li je uspešno otvoren
if ( $fajl = fopen("jsonIzBaze2.json", 'w') ) {
    // upis podataka u fajl
    if ( fwrite($fajl, $jsonString) ) {
        //zatvaranje fajla
        fclose($fajl);
    }
}
