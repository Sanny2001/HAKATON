<?php
// proveravamo da li je prosleđen parametar pod ključem ID u GET zahtevu
if (!isset($_GET['id'] ) || is_null($_GET['id']) ) {
    include "connection.php";
    
    echo "Select sve postove bez uslova";
    $upit = "SELECT * FROM post";
    $rezultat = $konekcija->query($upit);
    $upit2 = "SELECT * FROM user ";
    $rezultat2 = $konekcija->query($upit2);

    $red2 = $rezultat2->fetch_object();
    while ($red = $rezultat->fetch_object()) {
        echo "<div class="."container".">
        <div class="."item mb-5".">
            <div class="."media".">
                <img class="."mr-3 img-fluid post-thumb d-none d-md-flex"." src="."assets/images/blog/blog-post-thumb-1.jpg"." alt="."image".">
                <div class="."media-body".">
                    <h3 class="."title mb-1"."><a href="."blog-post.html".">";?><?php echo "$red->title"?><?php echo "</a></h3>
                    <div class="."meta mb-1"."><span class="."date".">";?><?php echo "$red2->email"?><?php echo "</span><span class="."time".">";?><?php echo "$red->location"?><?php echo "</span></div>
                    <div class="."intro".">";?><?php echo "$red->descr"?><?php echo "</div>
                </div><!--//media-body-->
            </div><!--//media-->
        </div><!--//item-->

        
    </div>";
    }




} else {
    // ako jeste prosleđen, čuvamo ga u promenljivoj $pomocna
    if ($_GET["id"] == -1) {
        echo "a";
    } else {
        $pomocna = $_GET["id"];
        //uspostavljanje konekcije
        include "connection.php";

        //upit za vraćanje podataka o predmetu koja je selektovan (preko ID-ja)
        $upit = "SELECT * FROM post WHERE user_id = '$pomocna'";
        $upit2 = "SELECT * FROM user WHERE id = '$pomocna'";


        // čuvamo rezultat prethodnog upita
        $rezultat = $konekcija->query($upit);
        $rezultat2 = $konekcija->query($upit2);
        $red2 = $rezultat2->fetch_object();

        //ispis naziva kolona u tabeli
    

        //ispis podataka o zemlji
        while ($red = $rezultat->fetch_object()) {
            echo "<div class="."container".">
            <div class="."item mb-5".">
                <div class="."media".">
                    <img class="."mr-3 img-fluid post-thumb d-none d-md-flex"." src="."assets/images/blog/blog-post-thumb-1.jpg"." alt="."image".">
                    <div class="."media-body".">
                        <h3 class="."title mb-1"."><a href="."blog-post.html".">";?><?php echo "$red->title"?><?php echo "</a></h3>
                        <div class="."meta mb-1"."><span class="."date".">";?><?php echo "$red2->email"?><?php echo "</span><span class="."time".">";?><?php echo "$red->location"?><?php echo "</span></div>
                        <div class="."intro".">";?><?php echo "$red->descr"?><?php echo "</div>
           
                    </div><!--//media-body-->
                </div><!--//media-->
            </div><!--//item-->

            
        </div>";
        }
        
    }


}
