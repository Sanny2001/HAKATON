<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">

 <script defer src="https://use.fontawesome.com/releases/v5.7.1/js/all.js" integrity="sha384-eVEQC9zshBn0rFj4+TU78eNA19HMNigMviK/PU/FFjLXqa/GKPgX58rvt5Z8PLs7" crossorigin="anonymous"></script>
    
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="theme-1.css">
	   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- naša klijentska skripta -->
    <script>
        // koristimo jQuery da proverimo da li je završeno učitavanje dokumenta
    
        $(document).ready(function() {
          // on load umesto change 
            $("#listaPredmeta").change(function () {
                var vrednost = $("#listaPredmeta").val();
                if (vrednost >0 ){ }
                else vrednost= -1;
                $.ajax({
                    url: "textp.php",
                    type: "get",
                    data: {
                        id: vrednost
                    },
                    success: function(predmeti) {
                        $("#popuni").html(predmeti);
                    }
                });
            });
        });
    </script>
</head>
<body class="page-top">
 <?php  if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
     include('includes/navuser.php');

 }
    else
      include('includes/nav.php');
?> 
 <?php
    // 
    include "connection.php";
    // 
    $upit = "select distinct user.id,user.email from post inner join user on post.user_id=user.id;";
    

    // čuvanje rezultata izvršenja upita u promenljivoj
    $rezultat = $konekcija->query($upit);
    ?>
	
  <section class="page-section bg-primary">
  <div class="container" >
    <div class="row" style="margin-bottom: 3%">
      <h2 class="col-12 text-center mt-0" style="width: 100%; color:white">Pogledajte danasju prognozu vremena</h2>
    </div>
    <hr class="divider light my-4">
    <div class="row" style="margin-top: 5%">
      <input id="city" class="col-6 form-control" style="width:100%" placeholder="Grad"></input>
      <button id="getWeatherForcast" class="col-6 btn btn-light" style="width:100%">Pretrazi</button>
    </div>
    <div class="row" style="margin-top: 3%">
      <div class="ShowWeatherForcast col-12 text-center" style="width:100%; color: white"></div>
    </div>
  </div>
</section>
  <script type="text/javascript">
    $(document).ready(function(){
      
      $("#getWeatherForcast").click(function(){
                
                var city = $("#city").val();
            var key  = '4de3768c62b67fe359758977a3efc069';
            
            $.ajax({
              url:'http://api.openweathermap.org/data/2.5/weather',
              dataType:'json',
              type:'GET',
              data:{q:city, appid: key, units: 'metric'},

              success: function(data){
                var wf = '';
                $.each(data.weather, function(index, val){

                  wf += '<p><b>' + data.name + "</b><img src="+ val.icon + ".png></p>"+ data.main.temp + '&deg;C ' + 
                  ' | ' + val.main + ", " + val.description 

                });
              
               $(".ShowWeatherForcast").html(wf);
              }

            })

      });
    });
  </script>
    <form>
            <!-- iz padajućeg menija može da se izabere predmet o kom želimo da vidimo podatke -->
            <b>Izaberi korisnika:</b>

            <!-- padajući meni pravimo preko elementa "select",
            a stavke padajućeg menija su elementi "option" -->
            <select name="predmeti" id="listaPredmeta">
                <!-- jedan prazan option -->
                <option value="kljuc">sadrzaj</option>
                <?php
                
                // dok postoje redovi u rezultatu, nad njima pozivamo funkciju fetch_object()
                // otkomentarisati sledeći red
                while ($red = $rezultat->fetch_object()  )  {
                    
                   
                    ?>
                    <!-- atribut value treba da bude ID drŽave, a tekstualni sadržaj elementa option treba da bude IME DRŽAVE  -->
                    <option value="<?php echo "$red->id"; ?>"> <?php echo "$red->email"; ?> </option>
                <?php
                    // otkomentarisati sledeći red
                }
                ?>
            </select>
        </form>
           <section class="blog-list px-3 py-5 p-md-5">
        <div id="popuni">
                Podaci o selektovanom predmetu će biti prikazani umesto ovog div elementa. Stranica se ne učitava ponovo.
				<div style="right: 150px;">
                <button><i class="fas fa-trash-alt"></i></button>
              <button><i class="fas fa-edit"></i></button>
              </div>  
            </div>
		    
        
		</section>



<section class="page-section bg-dark text-white" id="contact">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">Kontakt</h2>
          <hr class="divider my-4">
          <p class="text-muted mb-5">Pozovite nas ili nas kontaktirajte putem e-mail</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <div>+1 (202) 555-0149</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <a class="d-block" href="mailto:contact@yourwebsite.com">nas@emajl.com</a>
        </div>
      </div>
    </div>
  </section>
   <?php
    $konekcija->close();
    ?>
   <?php 
  include ('includes/footer.php');
  ?>
    <script type="text/javascript" src="js/bgcc.js"></script>

</body>
</html>
