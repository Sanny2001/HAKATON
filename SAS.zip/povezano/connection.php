<?php
$adresaHosta = "localhost";
$korisnickoIme = "root";
$sifra = "root";
$imeBaze = "hzs1";
$konekcija = new mysqli($adresaHosta, $korisnickoIme, $sifra, $imeBaze);
$konekcija->set_charset("utf8");

if ($konekcija->connect_errno) {
    printf("Konekcija neuspešna: %s\n", $konekcija->connect_error);
    exit();
}

// $konekcija->set_charset("utf8");
?>