<?php
session_start();
$b=$_POST['a'];
$a=$_SESSION['id'];
echo "$b";
    require "connection.php";

    $sql = "insert into friends(id_1,id_2) values('$a','$b');";
$result = $konekcija->query($sql);

include("connection.php");
$sql2="update  temp set status=True where id_1='$a' and id_2='$b' ";
$result2=$konekcija->query($sql2);



$konekcija->close();