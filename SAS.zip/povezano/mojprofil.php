<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">

<style>
/* Add padding to containers */
body{
  background-color: #d3d3d338;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: red;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #f4623a;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #745a5296;
  text-align: center;
}
</style>
 <script>
        // koristimo jQuery da proverimo da li je završeno učitavanje dokumenta
        $(document).ready(function() {
          // on load umesto change 
            $("#listaPredmeta").change(function () {
                var vrednost = $("#listaPredmeta").val();
                if (vrednost >0 ){ }
                else vrednost= -1;
                $.ajax({
                    url: "mojprofilb.php",
                    type: "get",
                    data: {
                        id: vrednost
                    },
                    success: function(predmeti) {
                        $("#popuni").html(predmeti);
                    }
                });
            });
        });
    </script>
</head>
<body class="page-top">
  <?php  if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
     include('includes/navuser.php');

 }
    else
      include('includes/nav.php');
?>
<?php
$a=$_SESSION['id'];
    // 
    include "connection.php";
    // 
    $upit = "select * from user where id='$a'";
    

    // čuvanje rezultata izvršenja upita u promenljivoj
    $rezultat = $konekcija->query($upit);
    ?>
    <?php
    
    $konekcija->close();
    ?>
  <div class="container" style="margin-top:6%">
    <div class="row my-2">
        <div class="col-lg-8 order-lg-2">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a href="" data-target="#profile" data-toggle="tab" class="nav-link active">Profile</a>
                </li>
                <li class="nav-item">
                    <a href="" data-target="#edit" data-toggle="tab" class="nav-link">Edit</a>
                </li>
                <li class="nav-item">
                    <a href="addPost.php" class="nav-link">Dodaj post</a>
                </li>
                 <li class="nav-item">
                    <a href="mojipostovi.php" class="nav-link">Moji postovi</a>
                </li>
                  <li class="nav-item">
                    <a href="prijatelji.php" class="nav-link">Prijatelji</a>
                </li>
                <li class="nav-item">
                    <a href="chat.php" class="nav-link">Chat</a>
                </li>
            </ul>
             
          <?php
                
                // dok postoje redovi u rezultatu, nad njima pozivamo funkciju fetch_object()
                // otkomentarisati sledeći red
                while ($red = $rezultat->fetch_object()  )  {
                    
                   
                    ?>
                    <!-- atribut value treba da bude ID drŽave, a tekstualni sadržaj elementa option treba da bude IME DRŽAVE  -->
                    <option value="<?php echo "$red->id"; ?>"> <?php echo "$red->email"; ?> </option>
               
            <div class="tab-content py-4">
                <div class="tab-pane active" id="profile">
                    <h5 class="mb-3"><?php echo "$red->f_name  ";echo "$red->l_name  " ?></h5>
                    <div class="row">
                        <div class="col-md-6">
                            <h6><?php if(is_null($red->datum_rodj)) echo "Nije postavljeno"; else echo "$red->datum_rodj  "; ?></h6>
                            <p>
                            <?php if(is_null($red->drzava)) echo "Nije postavljeno"; else echo "$red->drzava  "; ?>
                            </p>
                            <h6><?php if(is_null($red->pol)) echo "Nije postavljeno"; else echo "$red->pol  "; ?></h6>
                            <p>
                            <?php if(is_null($red->phone)) echo "Nije postavljeno"; else echo "$red->phone  "; ?>
                            </p>
                        </div>
                   
                        
                    </div>
                    <!--/row-->
                </div>
                
                <div class="tab-pane" id="edit">
                    <form role="form" method="POST" action="updatep.php"  >
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">First name</label>
                            <div class="col-lg-9">
                                <input class="form-control" name="f_name" type="text" value="<?php if(is_null($red->f_name)) echo "Nije postavljeno"; else echo "$red->f_name  "; ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Last name</label>
                            <div class="col-lg-9">
                                <input class="form-control" type="text" name="l_name" value="<?php if(is_null($red->l_name)) echo "Nije postavljeno"; else echo "$red->l_name  "; ?>">
                            </div>
                        </div>
                        
                       
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Drzava</label>
                            <div class="col-lg-9">
                                <input class="form-control" name="drzava" type="text" value="<?php if(is_null($red->drzava)) echo "Nije postavljeno"; else echo "$red->drzava  "; ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Password</label>
                            <div class="col-lg-9">
                                <input class="form-control" name="password" type="password" value="<?php if(is_null($red->password)) echo "Nije postavljeno"; else echo "$red->password  "; ?>">
                            </div>
                        </div>
                   
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label"></label>
                            <div class="col-lg-9">
                                <input type="reset" class="btn btn-secondary" value="Cancel">
                                <input type="submit" class="btn btn-primary" value="Save Changes">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
                    // otkomentarisati sledeći red
                }
                ?>
        <div class="col-lg-4 order-lg-1 text-center">
            <h6 class="mt-2">Upload a different photo</h6>
            <label class="custom-file">
                <input type="file" id="file" class="custom-file-input">
                <span class="custom-file-control">Choose file</span>
            </label>
        </div>
    </div>
</div>


<section class="page-section bg-dark text-white" id="contact">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">Kontakt</h2>
          <hr class="divider my-4">
          <p class="text-muted mb-5">Pozovite nas ili nas kontaktirajte putem e-mail</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <i class="fas fa-phone fa-3x mb-3 text-muted"></i>
          <div>+1 (202) 555-0149</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <a class="d-block" href="mailto:contact@yourwebsite.com">nas@emajl.com</a>
        </div>
      </div>
    </div>
  </section>
 <?php 
  include ('includes/footer.php');
  ?>
    <script type="text/javascript" src="js/bgcc.js"></script>

  <!-- Bootstrap core JavaScript -->
  
  
  
</body>
</html>
