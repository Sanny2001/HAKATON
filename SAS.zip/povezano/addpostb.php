<?php
    session_start();
    foreach ($_SESSION as $key=>$val)
    echo $key." ".$val."<br/>";
    $email=$_POST['title'];
    $f_name=$_POST['descr'];
    $l_name=$_POST['location'];
    $a=$_SESSION['id'];

    $password=$_POST['time'];
        require "connection.php";
    
        $sql = "insert into post(title,descr,location,time,user_id) values('$email','$f_name','$l_name','$password','$a');";
    $result = $konekcija->query($sql);
    
    
    header('location:mojipostovi.php');
    $konekcija->close();