<?php
session_start();
$b=$_SESSION['id'];
   $f_name=$_POST['f_name'];
   $l_name=$_POST['l_name'];
   $drzava=$_POST['drzava'];
   $password=$_POST['password'];
   include "connection.php";

   $sql = "update user set f_name='$f_name', l_name='$l_name',drzava='$drzava',password='$password' where id='$b'";
   header('location:index.php');
   $result = $konekcija->query($sql);