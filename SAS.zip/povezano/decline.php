<?php
session_start();
$b=$_POST['a'];
$a=$_SESSION['id'];
echo "$b";
    require "connection.php";


include("connection.php");
$sql2="delete from temp where id_1='$a' and id_2='$b'";
$result2=$konekcija->query($sql2);



$konekcija->close();