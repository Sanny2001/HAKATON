<?php
session_start();
$b=$_POST['p'];
$a=$_SESSION['id'];
echo "$b";
    require "connection.php";

    $sql = "insert into temp(id_1,id_2) values('$a','$b');";
$result = $konekcija->query($sql);

include("connection.php");



$konekcija->close();