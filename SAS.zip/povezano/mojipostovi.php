<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <!-- Theme CSS - Includes Bootstrap -->
  <link href="css/creative.min.css" rel="stylesheet">

 <script defer src="https://use.fontawesome.com/releases/v5.7.1/js/all.js" integrity="sha384-eVEQC9zshBn0rFj4+TU78eNA19HMNigMviK/PU/FFjLXqa/GKPgX58rvt5Z8PLs7" crossorigin="anonymous"></script>
    
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="theme-1.css">
    <script>
        // koristimo jQuery da proverimo da li je završeno učitavanje dokumenta
        $(document).ready(function() {
          // on load umesto change 
            $("#listaPredmeta").change(function () {
                var vrednost = $("#listaPredmeta").val();
                if (vrednost >0 ){ }
                else vrednost= -1;
                $.ajax({
                    url: "textp.php",
                    type: "get",
                    data: {
                        id: vrednost
                    },
                    success: function(predmeti) {
                        $("#popuni").html(predmeti);
                    }
                });
            });
        });
    </script>
</head>
<body class="page-top">
  <?php  if(isset($_SESSION['email']) && !empty($_SESSION['email'])) {
     include('includes/navuser.php');

 }
    else
      include('includes/nav.php');
?>
  <?php
    // 
    include "connection.php";
    // 
    $b=$_SESSION['id'];
    $upit = "select * from post where user_id='$b'";
    

    // čuvanje rezultata izvršenja upita u promenljivoj
    $rezultat = $konekcija->query($upit);
    ?>
    <?php
    while ($red = $rezultat->fetch_object()  )  {
                    
                   
        ?>
  <section class="blog-list px-3 py-5 p-md-5" style="margin-top:5%">
        <div class="container">
          <div class="item mb-5">
            <div class="media">
              <img class="mr-3 img-fluid post-thumb d-none d-md-flex" src="assets/images/blog/blog-post-thumb-1.jpg" alt="image">
              <div class="media-body">
                <h3 class="title mb-1"><a href="blog-post.html"><?php echo "$red->title"; ?></a></h3>
                <div class="meta mb-1"><span class="date"><?php echo"$red->location"; ?></span><span class="time"><?php echo"$red->time";?></span></div>
                <div class="intro"> <?php echo "$red->descr";?></div>
                
                <div style="right: 150px;">
               <form method="POST" action="deletep.php"> <button type="sumbit"><input type="hidden" name="idd" value="<?php echo"$red->id"?>"/><i class="fas fa-trash-alt"></i></button> </form>
              </div>  
              </div><!--//media-body-->
            </div><!--//media-->
          </div><!--//item-->
        </div>
      </section>
      <?php
                    // otkomentarisati sledeći red
                }
                ?>
    



<section class="page-section bg-dark text-white" id="contact">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">Kontakt</h2>
          <hr class="divider my-4">
          <p class="text-muted mb-5">Pozovite nas ili nas kontaktirajte putem e-mail</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <div>+1 (202) 555-0149</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <a class="d-block" href="mailto:contact@yourwebsite.com">nas@emajl.com</a>
        </div>
      </div>
    </div>
  </section>
  

  <!-- Bootstrap core JavaScript -->
  
  
  
  <!-- Custom scripts for this template -->
  <?php 
  include ('includes/footer.php');
  ?>
    <script type="text/javascript" src="js/bgcc.js"></script>

</body>
</html>
