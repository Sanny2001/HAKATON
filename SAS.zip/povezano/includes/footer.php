<footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Copyright &copy; All rights reserved by us</div>
    </div>
  </footer>
